import os
import re
import time
import urllib.request

from nonebot.adapters.cqhttp import Bot, Event
from nonebot.adapters.cqhttp.message import Message
from nonebot.permission import SUPERUSER
from nonebot.plugin import export, on_message
from nonebot.rule import Rule
from nonebot.typing import T_State

export = export()
export.name = '合并转发图片下载'
export.usage = 'https://www.bilibili.com/read/cv11148187'

def checker():
    async def _checker(bot: Bot, event: Event, state: T_State) -> bool:
        text = str(event.get_message())
        if 'CQ:forward' in text:
            print('downloader get info')
            return True
    return Rule(_checker)

downloader = on_message(rule = checker(),permission=SUPERUSER)
@downloader.handle()
async def downloader_handle(bot: Bot, event: Event, state: T_State):
    _,message_id_raw = str(event.get_message()).split('id=')
    message_id,_ = message_id_raw.split(']')
    get_msg = await bot.call_api('get_forward_msg',**{'message_id': message_id})
    url_list = re.findall('https?://[^=]*=2', str(get_msg))
    await downloader.send(f'已检测到{len(url_list)}个图片，开始下载')
    await downloader.finish(get_pic(url_list))

def get_pic(url_list):
    path = os.getcwd()
    def download(url_list):
        num = 0
        erronum = 0
        for url in url_list:
            num += 1
            try:
                pictime = time.strftime("%Y%m%d-%H%M%S")
                urllib.request.urlretrieve(url,f'{path}/picture/{pictime}--{num}.png')
            except Exception as e:
                print(e)
                erronum += 1
                pass
        return f'总共{num}张图片，下载完成{num-erronum}张图片，有{erronum}张未下载成功，储存路径为{path}文件夹下的picture文件夹'
    try:
        os.mkdir(f'{path}/picture')
    except Exception as e:
        pass
    return download(url_list)
        