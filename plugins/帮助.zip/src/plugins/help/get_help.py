from nonebot.plugin import require,plugins
import os,re

def helpmsg(module_name):
    #读取插件名及用法
    plugin_dic = {}
    for plugin_name in plugins.keys():
        try:
            name,usage = get_info_from_plugin(plugin_name)
            plugin_dic[name] = usage
        except:
            name,usage = plugin_name,'未能成功找到该插件的用法'
            plugin_dic[name] = usage
    #匹配查询内容
    if module_name == '':
        msg = '\n'.join(plugin_dic.keys())
        return  f'现已加载的插件列表有:\n{msg}\n使用"/help 插件名"以获取具体信息'
    elif '--linux-' in module_name:
        _,method = module_name.split('linux-')
        return get_sys_info(method)
    elif module_name in plugin_dic:
        return plugin_dic[module_name]
    else:
        return "未能成功找到该插件，使用/help以获取插件列表"
    
def get_info_from_plugin(plugin):
    plugin_info = require(plugin)
    name = plugin_info.name
    usage = plugin_info.usage
    return name,usage

def get_sys_info(method):
    sys_info_raw = os.popen('vmstat').readlines()
    sys_info_mid1 = sys_info_raw[2]
    sys_info_mid2 = re.findall('\d*',sys_info_mid1)
    sys_info = []
    for info in sys_info_mid2:
        if info.isdigit():
            sys_info.append(info)
    if method == 'a':
        return f'详细数据:\
            \n——procs\
            \nr:{sys_info[0]}\
            \nb:{sys_info[1]}\
            \n——memory\
            \nswpd:{sys_info[2]}\
            \nfree:{sys_info[3]}\
            \nbuff:{sys_info[4]}\
            \ncache:{sys_info[5]}\
            \n——swap\
            \nsi:{sys_info[6]}\
            \nso:{sys_info[7]}\
            \n——io\
            \nbi:{sys_info[8]}\
            \nbo:{sys_info[9]}\
            \n——system\
            \nin:{sys_info[10]}\
            \ncs:{sys_info[11]}\
            \n——cpu\
            \nus:{sys_info[12]}\
            \nsy:{sys_info[13]}\
            \nid:{sys_info[14]}\
            \nwa:{sys_info[15]}\
            \nst:{sys_info[16]}'
    elif method == 'b':
        #内存
        raminfo_raw = os.popen('free -m').readlines()
        raminfo = []
        raminfo_temp = re.findall('\d*', raminfo_raw[1])
        for info in raminfo_temp:
            if info.isdigit():
                raminfo.append(info)
        return f'简要分析:\
        \nCPU使用率:{100-int(sys_info[14])}%\
        \nRAM使用率:{(1-int(raminfo[5])/int(raminfo[0]))*100:.2f}%'