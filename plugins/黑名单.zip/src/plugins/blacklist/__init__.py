from nonebot.plugin import on_command,export
from nonebot.adapters.cqhttp import Bot, Event
from nonebot.permission import SUPERUSER
from nonebot.adapters.cqhttp.permission import GROUP_ADMIN,GROUP_OWNER,PRIVATE_FRIEND

from service.blacklist import db,check 


export = export()
export.name = '黑名单'
export.usage = '''https://www.bilibili.com/read/cv11109352'''

#获取指令
blacklist = on_command('blist', priority=10,permission=GROUP_ADMIN|GROUP_OWNER|SUPERUSER)
@blacklist.handle()
async def blacklist_handle(bot: Bot, event: Event):
    if check('blist',str(event.get_session_id())):
        await blacklist.finish(db.analysis(str(event.get_message()),str(event.get_session_id())))