from nonebot.plugin import on_command,on_message,export
from nonebot.adapters.cqhttp import Bot, Event
from nonebot.adapters.cqhttp.message import Message
from nonebot.permission import SUPERUSER
from nonebot.adapters.cqhttp.permission import GROUP_ADMIN,GROUP_OWNER,PRIVATE_FRIEND

import service.blacklist as black
from .database import db

debugmod = False

export = export()
export.name = '基础回复'
export.usage = '''https://www.bilibili.com/read/cv11129948'''
       
#乒乓球(bushi)
ping = on_command('ping', priority=5)
@ping.handle()
async def _(bot: Bot, event: Event):
    if black.check('ping',str(event.get_session_id())):
        await ping.finish(message = Message('pong!'))
#——————————————通用数据库操作——————————————
#增添通用关键词
add_key_universal = on_command('addu', priority=49,permission=SUPERUSER)
@add_key_universal.handle()
async def add_key_universal_handle(bot: Bot, event: Event):
    if black.check('addu',str(event.get_session_id())):
        await add_key_universal.finish(message = Message(db.insert(str(event.get_message()),'universal')))
#删除通用关键词
del_key_universal = on_command('delu', priority=49,permission=SUPERUSER)
@del_key_universal.handle()
async def del_key_universal_handle(bot: Bot, event: Event):
    if black.check('delu',str(event.get_session_id())):
        await del_key_universal.finish(message = Message(db.delete(str(event.get_message()),'universal')))
#清空通用关键词列表
clear_keys_universal = on_command('clearu', priority=49,permission=SUPERUSER)
@clear_keys_universal.handle()
async def clear_keys_universal_handle(bot: Bot, event: Event):
    if black.check('clearu',str(event.get_session_id())):
        await clear_keys_universal.finish(message = Message(db.delete('all','universal')))
#查看通用关键词列表
show_key_universal = on_command('showu', priority=49)
@show_key_universal.handle()
async def show_key_universal_handle(bot: Bot, event: Event):
    if black.check('showu',str(event.get_session_id())):
        await show_key_universal.finish(message = Message('通用关键词列表：\n'+str(db.check('universal'))))
#查看单个通用关键词的详细信息
check_key_universal = on_command('checku', priority=49)
@check_key_universal.handle()
async def check_key_universal_handle(bot: Bot, event: Event):
    if black.check('checku',str(event.get_session_id())):
        info = db.precise_search(str(event.get_message()),'universal')
        await check_key_universal.finish(message = Message(f"通用关键词信息:\
                            \n关键词名:{info['keyword']}\
                            \n回复内容:{info['replyword']}\
                            \n添加者id:{info['userid']}\
                            \n优先度:{info['priority']}\
                            \n累计使用次数:{info['usedcount']}"))
#——————————————私有数据库操作——————————————
#增添私有关键词
add_key = on_command('add', priority=50)
@add_key.handle()
async def add_key_handle(bot: Bot, event: Event):
    if black.check('add',str(event.get_session_id())):
        await add_key.finish(message = Message(db.insert(str(event.get_message()),str(event.get_session_id()))))
#删除私有关键词
del_key = on_command('del', priority=50)
@del_key.handle()
async def del_key_handle(bot: Bot, event: Event):
    if black.check('del',str(event.get_session_id())):
        await del_key.finish(message = Message(db.delete(str(event.get_message()),str(event.get_session_id()))))
#清空私有关键词列表
clear_keys = on_command('clear', priority=50,permission=GROUP_ADMIN|GROUP_OWNER|PRIVATE_FRIEND|SUPERUSER)
@clear_keys.handle()
async def clear_keys_handle(bot: Bot, event: Event):
    if black.check('clear',str(event.get_session_id())):
        await clear_keys.finish(message = Message(db.delete('all',str(event.get_session_id()))))
#查看私有关键词列表
show_key = on_command('show', priority=50)
@show_key.handle()
async def show_key_handle(bot: Bot, event: Event):
    if black.check('show',str(event.get_session_id())):
        await show_key.finish(message = Message('私有关键词列表：\n'+str(db.check(str(event.get_session_id())))))
#查看单个私有关键词的详细信息
check_key = on_command('check', priority=50)
@check_key.handle()
async def check_key_handle(bot: Bot, event: Event):
    if black.check('check',str(event.get_session_id())):
        info = db.precise_search(str(event.get_message()),str(event.get_session_id()))
        await check_key.finish(message = Message(f"私有关键词信息:\
                            \n关键词名:{info['keyword']}\
                            \n回复内容:{info['replyword']}\
                            \n添加者id:{info['userid']}\
                            \n优先度:{info['priority']}\
                            \n累计使用次数:{info['usedcount']}"))
        
#——————————————回复处理——————————————
reply = on_message(priority=100)
@reply.handle()
async def reply_handle(bot: Bot, event: Event):
    if black.check('reply',str(event.get_session_id())):
        replymsg = db.precise_search(str(event.get_message()).strip(),str(event.get_session_id()))
        if not replymsg['keyword'] == "non":
            db.usedcount(replymsg)
            await reply.finish(message = Message(replymsg['replyword']))
                       