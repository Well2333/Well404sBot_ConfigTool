import sqlite3

debugmod = False

#分析数据，操作数据库
class DB:
    #连接数据库
    def __init__(self):
        self.conn = sqlite3.connect("database/basic_reply.db")
        self.cur = self.conn.cursor()
    #——————解析部分——————
    #解析群组或用户身份ID
    def session_id_analysis(self,session_id):
        if "group" in session_id:
            _,groupid,userid = session_id.split('_')
            session_id_analyzed = {"groupid":f"group{groupid}", "userid":userid}
        else:
            session_id_analyzed = {"groupid":"user", "userid":session_id}
        if debugmod:
            print(f'——————session_id_analysis:——————\
                    \n{str(session_id_analyzed)}\
                    \n————————————————————————————————')        
        return session_id_analyzed
    #解析具体内容
    def get_message_analysis(self,get_message):
        get_message = get_message.strip()
        if "pri=" in get_message:
            get_message,priority = get_message.split('pri=')
            priority = int(priority)
            get_message = get_message.strip()
        else:
            priority = 50
        keyword,replyword = get_message.split("===")
        if 'image' in keyword:
            for temp in keyword.split(','):
                if 'file=' in temp:
                    keyword = temp
        get_message_analyzed = {"keyword"  :keyword, 
                                "replyword":replyword, 
                                "priority" :priority}
        if debugmod:
            print(f'——————get_message_analysis:——————\
                    \n{str(get_message_analyzed)}\
                    \n————————————————————————————————')
        return get_message_analyzed    
    #精确搜索
    def precise_search(self,inputmsg,session_id,only_private=False):
        session_id_analyzed = self.session_id_analysis(session_id)
        #优先搜素私有关键词
        if not session_id == "universal":
            try:
                dbname = session_id_analyzed["groupid"]
                allinfo = self.cur.execute(f'SELECT keyword, replyword, userid, priority, usedcount from "{dbname}" ORDER BY priority DESC')
                for row in allinfo:
                    if debugmod:
                        print(str(row[0]))
                    if str(row[0]) in inputmsg:
                        if ('CQ:image' in inputmsg) and (not '.image' in str(row[0])):
                            pass
                        else:
                            returnmsg = {'keyword' :row[0],
                                        'replyword':row[1],
                                        'userid'   :row[2],
                                        'priority' :row[3],
                                        'usedcount':row[4],
                                        'db':dbname}
                            if debugmod:
                                print(f'——————returnmsg:——————\
                                        \n{str(returnmsg)}\
                                        \n———————————————————————')
                            return returnmsg             
            except sqlite3.OperationalError:
                self.creat_table(session_id_analyzed)
                returnmsg = {'keyword' :'non',
                            'replyword':'non',
                            'userid'   :'non',
                            'priority' :'non',
                            'usedcount':'non',
                            'db':'just_builded'}
                if debugmod:
                    print(f'——————returnmsg:——————\
                            \n{str(returnmsg)}\
                            \n———————————————————————')     
                return returnmsg
        #搜索通用关键词
        if not only_private:
            try:
                allinfo = self.cur.execute(f'SELECT keyword, replyword, userid, priority, usedcount from universal ORDER BY priority DESC')
                for row in allinfo:
                    if row[0] in inputmsg:
                        if ('CQ:image' in inputmsg) and (not '.image' in str(row[0])):
                            pass
                        else:
                            returnmsg = {'keyword' :row[0],
                                        'replyword':row[1],
                                        'userid'   :row[2],
                                        'priority' :row[3],
                                        'usedcount':row[4],
                                        'db':'universal'}
                            if debugmod:
                                print(f'——————returnmsg:——————\
                                        \n{str(returnmsg)}\
                                        \n———————————————————————')
                            return returnmsg
            except sqlite3.OperationalError:
                self.creat_table({'groupid':'universal'})  
        returnmsg = {'keyword' :'non',
                    'replyword':'non',
                    'userid'   :'non',
                    'priority' :'non',
                    'usedcount':'non',
                    'db':'non'}
        if debugmod:
            print(f'——————returnmsg:——————\
                    \n{str(returnmsg)}\
                    \n———————————————————————')                
        return returnmsg        
    #——————执行部分——————
    #创建新表
    def creat_table(self,session_id_analyzed):
        self.cur.execute(
            f'''CREATE TABLE "{session_id_analyzed["groupid"]}"
            ("Id"	INTEGER NOT NULL UNIQUE,
            "keyword"	BLOB NOT NULL UNIQUE,
            "replyword"	BLOB NOT NULL,
            "userid"	BLOB NOT NULL,
            "priority"	INTEGER NOT NULL DEFAULT 50,
            "usedcount"	INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY("Id" AUTOINCREMENT))'''
            )
        self.conn.commit()
    #添加字段,若已经存在则修改字段
    def insert(self,get_message,session_id):
        get_message_analyzed = self.get_message_analysis(get_message)
        if session_id == 'universal':
            returnmsg = self.precise_search(get_message_analyzed['keyword'],'universal')            
            if returnmsg['keyword'] == 'non':
                self.cur.execute(f'''INSERT INTO 'universal' (keyword, replyword, userid, priority)
                    VALUES ("{get_message_analyzed['keyword']}", "{get_message_analyzed['replyword']}", "superuser", "{get_message_analyzed['priority']}")''')
                self.conn.commit()
                return f'''已成功添加通用关键词{get_message_analyzed['keyword']} ==> {get_message_analyzed['replyword']}'''
            else:
                if get_message_analyzed['priority'] == 50:
                    self.cur.execute(f'''UPDATE 'universal'
                                        SET replyword = "{get_message_analyzed['replyword']}" 
                                        WHERE keyword = "{returnmsg['keyword']}"''')
                else:
                    self.cur.execute(f'''UPDATE 'universal'
                                        SET replyword = "{get_message_analyzed['replyword']}", priority = "{get_message_analyzed['priority']}" 
                                        WHERE keyword = "{returnmsg['keyword']}"''')
                self.conn.commit()  
                return f'''已成功修改通用关键词{get_message_analyzed['keyword']} ==> {get_message_analyzed['replyword']}'''      
        else:
            session_id_analyzed = self.session_id_analysis(session_id)
            returnmsg = self.precise_search(get_message_analyzed['keyword'],session_id,only_private=True)
            if returnmsg['keyword'] == 'non':
                self.cur.execute(f'''INSERT INTO {session_id_analyzed["groupid"]} (keyword, replyword, userid, priority)
                    VALUES ("{get_message_analyzed['keyword']}", "{get_message_analyzed['replyword']}", "{session_id_analyzed["userid"]}", "{get_message_analyzed['priority']}")''')
                self.conn.commit()
                return f'''已成功添加{get_message_analyzed['keyword']} ==> {get_message_analyzed['replyword']}'''
            else:
                if get_message_analyzed['priority'] == 50:
                    self.cur.execute(f'''UPDATE "{session_id_analyzed["groupid"]}"
                                        SET replyword = "{get_message_analyzed['replyword']}" 
                                        WHERE keyword = "{returnmsg['keyword']}"''')
                else:
                    self.cur.execute(f'''UPDATE "{session_id_analyzed["groupid"]}" 
                                        SET replyword = "{get_message_analyzed['replyword']}", priority = "{get_message_analyzed['priority']}" 
                                        WHERE keyword = "{returnmsg['keyword']}"''')                       
                self.conn.commit()  
                return f'''已成功修改{get_message_analyzed['keyword']} ==> {get_message_analyzed['replyword']}'''      
    #删除\清空字段
    def delete(self,get_message,session_id):
        if session_id == "universal":
            if get_message == 'all':
                self.cur.execute(f'''DELETE FROM "universal"''')
                self.conn.commit()
                return '已成功清空全部关键词'
            else:                
                returnmsg = self.precise_search(get_message,session_id)
                if not returnmsg['keyword'] == 'non':
                    self.cur.execute(f'''DELETE FROM "universal"  
                                    WHERE keyword = "{returnmsg['keyword']}"''')
                    self.conn.commit()  
                    return f'''已成功删除{returnmsg['keyword']} ==> {returnmsg['replyword']}'''      
                else:
                    return '未找到此关键词'
        else:
            session_id_analyzed = self.session_id_analysis(session_id)
            if get_message == 'all':
                self.cur.execute(f'''DELETE FROM "{session_id_analyzed["groupid"]}"''')
                self.conn.commit()
                return '已成功清空全部关键词'
            else:
                returnmsg = self.precise_search(get_message,session_id)
                if not returnmsg['keyword'] == 'non':
                    self.cur.execute(f'''DELETE FROM "{session_id_analyzed["groupid"]}"  
                                    WHERE keyword = "{returnmsg['keyword']}"''')
                    self.conn.commit()  
                    return f'''已成功删除{returnmsg['keyword']} ==> {returnmsg['replyword']}'''      
                else:
                    return '未找到此关键词'
    #查看全部关键词
    def check(self,session_id):
        keylist = []
        if session_id == 'universal':
            try:
                allinfo = self.cur.execute(f'SELECT keyword, replyword, userid, priority, usedcount from universal ORDER BY priority DESC')            
                for row in allinfo:
                    keylist.append(row[0])
            except sqlite3.OperationalError:
                self.creat_table({'groupid':'universal'})   
        else:
            session_id_analyzed = self.session_id_analysis(session_id)
            try:
                allinfo = self.cur.execute(f'SELECT keyword, replyword, userid, priority, usedcount from "{session_id_analyzed["groupid"]}" ORDER BY priority DESC')
                for row in allinfo:
                    keylist.append(row[0])
            except sqlite3.OperationalError:
                self.creat_table(session_id_analyzed)   
        return keylist
    #使用次数统计
    def usedcount(self,replymsg):
        if replymsg['db'] == 'non':
            pass
        else:
            self.cur.execute(f'''UPDATE '{replymsg['db']}'
                                SET usedcount = "{int(replymsg['usedcount'])+1}" 
                                WHERE keyword = "{replymsg['keyword']}"''')
            
#实例化            
db = DB()